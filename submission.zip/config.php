<?php
$config=array();
$config['host']="localhost";
$config['user']="root";
$config['pass']="";
$config['database']="charts";
?>